from .constant_variables import MOCK_PATH

__all__ = ["MOCK_PATH"]
